/* TOUR DATA — one record per stop. Every record uses the same fields.
   These three stops are INVENTED EXAMPLES placed near the class teaching origin.
   They are not real campus locations. Replace them with records you verified yourself.
   Leave a value blank ("") or null if you have not verified it. Never let AI guess coordinates. */
const PLACES = [
  {
    name: "Example Stop 1 — Welcome",
    lon: -75.9300, lat: 40.3300,
    description: "Placeholder. Replace with what a new student should know here.",
    photo: "",                       // optional: a file in this folder, e.g. "stop1.jpg"
    photoAlt: "",
    source: "Invented example (not a real place)",
    checked: "2026-09-28"
  },
  {
    name: "Example Stop 2 — Study Spot",
    lon: -75.9250, lat: 40.3340,
    description: "Placeholder. Why would a visitor come here?",
    photo: "", photoAlt: "",
    source: "Invented example (not a real place)",
    checked: "2026-09-28"
  },
  {
    name: "Example Stop 3 — Food",
    lon: -75.9350, lat: 40.3270,
    description: "Placeholder. What are the hours, and who confirmed them?",
    photo: "", photoAlt: "",
    source: "Invented example (not a real place)",
    checked: "2026-09-28"
  }

  /* MISSING-DATA EXERCISE: on a copy, delete this line and the END line below, then reload.
  ,{
    name: "Unverified Stop",
    lon: null, lat: 40.3310,
    description: "Coordinates not verified yet.",
    photo: "", photoAlt: "",
    source: "", checked: ""
  }
  END OF EXERCISE */
];
if (typeof module !== 'undefined') module.exports = PLACES;
